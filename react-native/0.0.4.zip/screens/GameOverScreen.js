import React from "react";
import {View, Text, StyleSheet,Button,Image} from 'react-native';
import MainButton from "../components/MainButton";
import color from "../constants/color";

const GameOverScreen = props =>{

    return (
        <View style={styles.screen}>
            <Text>You Gusessed it.....   Game Over!!!</Text>

            <View style={styles.imageContainer}>
            <Image 
            fadeDuration = {1000}
            source = {require('../assests/success.png')} 
           //source ={{uri:'https://cdn.pixabay.com/photo/2016/05/05/23/52/mountain-summit-1375015_960_720.jpg'}}
            style={styles.image}
            resizeMode="cover"/>
            </View>

            <Text style={styles.highlight}>Number of rounds : {props.roundsNumber}</Text>
            <Text>User Number was : {props.userEnteredNumber}</Text>
            <MainButton  onPress={props.onRestart}>Start New Game</MainButton>
        </View>
    );
}

const styles = StyleSheet.create({
    screen : {
        flex :1,
        justifyContent : 'center',
        alignItems : 'center'
    },

    image : {
        width : '100%',
        height : '100%'
    },
    imageContainer : {
        borderRadius: 150,
        borderColor: 'black',
        borderWidth:3,
        width : 300,
        height: 300,
        overflow:'hidden'
    },
    highlight:{
        color: color.primary
    }
});

export default GameOverScreen;