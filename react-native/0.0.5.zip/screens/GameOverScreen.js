import React from "react";
import {View, Text, StyleSheet,Button,Image,Dimensions, ScrollView} from 'react-native';
import MainButton from "../components/MainButton";
import color from "../constants/color";

const GameOverScreen = props =>{

    return (
        <ScrollView>
        <View style={styles.screen}>
            <Text>You Gusessed it.....   Game Over!!!</Text>

            <View style={styles.imageContainer}>
            <Image 
            fadeDuration = {1000}
            source = {require('../assests/success.png')} 
           //source ={{uri:'https://cdn.pixabay.com/photo/2016/05/05/23/52/mountain-summit-1375015_960_720.jpg'}}
            style={styles.image}
            resizeMode="cover"/>
            </View>

            <Text style={styles.highlight}>Number of rounds : {props.roundsNumber}</Text>
            <Text>User Number was : {props.userEnteredNumber}</Text>
            <MainButton  onPress={props.onRestart}>Start New Game</MainButton>
        </View>
        </ScrollView>
    );
}

const styles = StyleSheet.create({
    screen : {
        flex :1,
        justifyContent : 'center',
        alignItems : 'center',
        paddingVertical : 10
    },

    image : {
        width : '100%',
        height : '100%'
    },
    imageContainer : {
        borderRadius: Dimensions.get('window').width * 0.3/2,
        borderColor: 'black',
        borderWidth:3,
        width : Dimensions.get('window').width * 0.3,
        height: Dimensions.get('window').width * 0.3,
        overflow:'hidden'
    },
    highlight:{
        color: color.primary
    }
});

export default GameOverScreen;