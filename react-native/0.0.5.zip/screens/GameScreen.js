import React, {useState, useRef, useEffect} from 'react';
import {
  View,
  Text,
  StyleSheet,
  Button,
  Alert,
  ScrollView,
  FlatList,
  Dimensions,
} from 'react-native';
import Card from '../components/Card';
import MainButton from '../components/MainButton';
import NumberConatiner from '../components/NumberContainer';
import Icon from 'react-native-vector-icons/AntDesign';

const generateRandomBetween = (min, max, exclude) => {
  min = Math.ceil(min);
  max = Math.floor(max);
  const randomNum = Math.floor(Math.random() * (max - min)) + min;

  if (randomNum === exclude) {
    return generateRandomBetween(min, max, exclude);
  } else {
    return randomNum;
  }
};

const renderListItem = (listLength, itemData) => (
  <View style={styles.listItem}>
    <Text>#{listLength - itemData.index}</Text>
    <Text>{itemData.item}</Text>
  </View>
);
const GameScreen = props => {
  const initialGuess = generateRandomBetween(1, 100, props.userChoice);
  const [currentGuess, setCurrentGuess] = useState(initialGuess);
  const [pastGuess, setPastGuess] = useState([initialGuess.toString()]);
  const [availableDeviceWidth, setAvailableDeviceWidth] = useState(Dimensions.get('window').width);

  const [availableDevicHeight, setAvailableDeviceHeight] = useState(Dimensions.get('window').height);

  useEffect(() => {
      const updateLayout = () => {
        setAvailableDeviceHeight(Dimensions.get('window').height);
      }
      Dimensions.addEventListener('change',updateLayout);

      return () =>{
          Dimensions.removeEventListener('change',updateLayout);
      }
  });

  const currentLow = useRef(1);
  const currentHigh = useRef(100);

  const {userChoice, onGameOver} = props;

  useEffect(() => {
    if (currentGuess === props.userChoice) {
      props.onGameOver(pastGuess.length);
    }
  }, [currentGuess, userChoice, onGameOver]);

  const nextGuessHandler = direction => {
    if (
      (direction === 'lower' && currentGuess < props.userChoice) ||
      (direction === 'greater' && currentGuess > props.userChoice)
    ) {
      Alert.alert('Wrong Choice!', 'Select the correct choice', [
        {text: 'Okay!', style: 'cancel'},
      ]);
      return;
    }
    if (direction === 'lower') {
      currentHigh.current = currentGuess;
    } else {
      currentLow.current = currentGuess + 1;
    }
    const nextNumber = generateRandomBetween(
      currentLow.current,
      currentHigh.current,
      currentGuess,
    );
    setCurrentGuess(nextNumber);
    setPastGuess(curPastGuess => [nextNumber.toString(), ...curPastGuess]);
  };

  if (availableDevicHeight < 500) {
    return (
      <View style={styles.screen}>
        <Text>Opponent's Guess</Text>
        <View style={styles.controls}>
          <MainButton onPress={nextGuessHandler.bind(this, 'lower')}>
            <Icon name="minus" size={28} color="white"></Icon>
          </MainButton>
          <NumberConatiner>{currentGuess}</NumberConatiner>
          <MainButton onPress={nextGuessHandler.bind(this, 'greater')}>
            <Icon name="plus" size={28} color="white"></Icon>
          </MainButton>
        </View>

        <View style={styles.listContainer}>
          {/*  <ScrollView contentContainerStyle={styles.list}>
          {pastGuess.map((guess, index) =>
            renderListItem(guess, pastGuess.length - index),
          )}
        </ScrollView>*/}
          <FlatList
            keyExtractor={item => item}
            data={pastGuess}
            renderItem={renderListItem.bind(this, pastGuess.length)}
            contentContainerStyle={styles.list}
          />
        </View>
      </View>
    );
  } 
    return (
      <View style={styles.screen}>
        <Text>Opponent's Guess</Text>
        <NumberConatiner>{currentGuess}</NumberConatiner>
        <Card style={styles.buttonContainer}>
          <MainButton onPress={nextGuessHandler.bind(this, 'lower')}>
            <Icon name="minus" size={28} color="white"></Icon>
          </MainButton>
          <MainButton onPress={nextGuessHandler.bind(this, 'greater')}>
            <Icon name="plus" size={28} color="white"></Icon>
          </MainButton>
        </Card>
        <View style={styles.listContainer}>
          {/*  <ScrollView contentContainerStyle={styles.list}>
          {pastGuess.map((guess, index) =>
            renderListItem(guess, pastGuess.length - index),
          )}
        </ScrollView>*/}
          <FlatList
            keyExtractor={item => item}
            data={pastGuess}
            renderItem={renderListItem.bind(this, pastGuess.length)}
            contentContainerStyle={styles.list}
          />
        </View>
      </View>
    );
  
};

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    padding: 10,
    alignItems: 'center',
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    // marginTop: 20,
    marginTop: Dimensions.get('window').height > 600 ? 20 : 10,
    width: 400,
    maxWidth: '90%',
  },

  listContainer: {
    width: '60%',
    flex: 1,
  },

  controls: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    width: '80%',
    alignItems: 'center',
  },

  listItem: {
    borderColor: 'black',
    borderWidth: 1,
    flexDirection: 'row',
    padding: 15,
    marginVertical: 10,
    backgroundColor: 'white',
    justifyContent: 'space-around',
    width: '100%',
  },

  list: {
    flexGrow: 1,
    // alignItems: 'center',
    justifyContent: 'flex-end',
  },
});

export default GameScreen;
